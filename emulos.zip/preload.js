window.addEventListener('DOMContentLoaded', () => {
  console.log('Renderer ready');
});
